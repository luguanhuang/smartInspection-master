#include "test.h"

#include "3rdparty/Log4Qt_POC/log4qt_poc.h"

Test::Test(QObject *parent)
    : QObject{parent}
{

}

void Test::TestLog()
{
    loggerPOCDebug("Class Test Debug");
    loggerPOCInfo("Class Test info");
    loggerPOCError("Class Test Error");
}

void Test::TestLog(QString msg)
{
    loggerPOCDebug(QStringLiteral("Test %1 %2"),msg,msg);
    loggerPOCInfo(QStringLiteral("Test %1 %2"),msg,msg);
    loggerPOCError(QStringLiteral("Test %1 %2"),msg,msg);
}

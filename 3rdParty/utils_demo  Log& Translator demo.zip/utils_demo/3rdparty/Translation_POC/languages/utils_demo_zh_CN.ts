<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>CusLanguageManager</name>
    <message>
        <location filename="../../../CusLanguageManager.qml" line="22"/>
        <source>Language</source>
        <translation type="unfinished">语言</translation>
    </message>
    <message>
        <location filename="../../../CusLanguageManager.qml" line="27"/>
        <source>English</source>
        <translation type="unfinished">英文</translation>
    </message>
    <message>
        <location filename="../../../CusLanguageManager.qml" line="38"/>
        <source>Chinese</source>
        <translation type="unfinished">中文</translation>
    </message>
    <message>
        <location filename="../../../CusLanguageManager.qml" line="82"/>
        <source>This is &quot;Test Text&quot;</source>
        <translation type="unfinished">这是&quot;测试文本&quot;</translation>
    </message>
    <message>
        <location filename="../../../CusLanguageManager.qml" line="88"/>
        <source>Change Language</source>
        <translation type="unfinished">切换语言</translation>
    </message>
</context>
<context>
    <name>CusLog4QtPOC</name>
    <message>
        <source>Language</source>
        <translation type="obsolete">语言</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="obsolete">英文</translation>
    </message>
    <message>
        <source>Chinese</source>
        <translation type="obsolete">中文</translation>
    </message>
    <message>
        <source>This is &quot;Test Text&quot;</source>
        <translation type="obsolete">这是&quot;测试文本&quot;</translation>
    </message>
    <message>
        <source>Change Language</source>
        <translation type="obsolete">切换语言</translation>
    </message>
    <message>
        <location filename="../../../CusLog4QtPOC.qml" line="16"/>
        <source>Debug</source>
        <translation type="unfinished">调试</translation>
    </message>
    <message>
        <location filename="../../../CusLog4QtPOC.qml" line="26"/>
        <source>info</source>
        <translation type="unfinished">信息</translation>
    </message>
    <message>
        <location filename="../../../CusLog4QtPOC.qml" line="37"/>
        <source>error</source>
        <translation type="unfinished">错误</translation>
    </message>
</context>
<context>
    <name>LanguageManager</name>
    <message>
        <location filename="../languagemanager.hpp" line="53"/>
        <source>--- Language changed to Chinese</source>
        <translation type="unfinished">切换到中文</translation>
    </message>
    <message>
        <location filename="../languagemanager.hpp" line="60"/>
        <source>--- Language changed to English</source>
        <translation type="unfinished">切换到英文</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../../main.qml" line="12"/>
        <source>MainWindow</source>
        <translation type="unfinished">主窗口</translation>
    </message>
</context>
</TS>

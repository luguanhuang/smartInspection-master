/******************************************************************************
 * All right reserved. See COPYRIGHT for detailed Information.
 *
 * @file       main.cpp
 * @brief      XXXX Function
 *
 * @author     plusone_chen
 * @version    1.0.0(major.minjor.patch(主版本号.次版本号.修订号))
 * @date       2022/08/12
 * @history
 ************  1.
 ************  2.
 *****************************************************************************/
#include <QGuiApplication>
#include <QQmlApplicationEngine>

#include <QFile>
#include <QLocale>
#include <QStringLiteral>
#include <QTranslator>
#include <QQmlContext>


#include "3rdparty/Log4Qt_POC/log4qt_poc.h"
#include "3rdparty/Translation_POC/languagemanager.hpp"



void InitLogger()
{
    //注册该机制后qml中调用console函数,qDebug()函数后会使用QMLMessageHandler回调函数返回
    qInstallMessageHandler(loggerPOC->QMLMessageHandler);

    QString configFileName = QGuiApplication::applicationDirPath() + "/log4qt.conf";
    if(QFile::exists(configFileName))
    {
        loggerPOC->init(configFileName);
    }
    else
    {
        loggerPOC->init();
    }
}

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QGuiApplication app(argc, argv);

    InitLogger();

//    Test m_test;
//    m_test.TestLog();
//    m_test.TestLog(QObject::tr("Chinese Test"));

//    QTranslator translator;
//    const QStringList uiLanguages = QLocale::system().uiLanguages();
//    for (const QString &locale : uiLanguages) {
//        const QString baseName = "utils_demo_" + QLocale(locale).name();
//        if (translator.load(":/i18n/" + baseName)) {
//            app.installTranslator(&translator);
//            break;
//        }
//        else{
//            loggerPOCInfo(QStringLiteral("tran name %1"),baseName);
//        }
//    }



    qmlRegisterUncreatableType<LanguageManager>("CPPTranslate", 1, 0, "LanguageManager", "不能创建LanguageManager对象");
    QQmlApplicationEngine engine;
    auto languageController = LanguageManager::instance(&engine);

    const QStringList uiLanguages = QLocale::system().uiLanguages(); //获取当前系统支持的语言
    for (const QString &locale : uiLanguages)
    {
        if(locale == "zh-CN")
        {
            languageController->loadLanguage(LanguageManager::Chinese);
            break;
        }
        else
        {
            languageController->loadLanguage(LanguageManager::English);
            break;
        }
    }

    engine.rootContext()->setContextProperty("cpplanguageController", languageController);

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);


    return app.exec();
}

#ifndef TEST_H
#define TEST_H

#include <QObject>


class Test : public QObject
{
    Q_OBJECT
public:
    explicit Test(QObject *parent = nullptr);

    void TestLog();
    void TestLog(QString msg);
signals:

};

#endif // TEST_H

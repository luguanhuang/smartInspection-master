/************************************************************************************************
** File created by QxEntityEditor 1.2.6 (2022/08/19 22:57) : please, do NOT
*modify this file ! **
************************************************************************************************/

#ifndef _PRECOMPILED_H_
#define _PRECOMPILED_H_

#ifdef _MSC_VER
#pragma once
#endif

#include <QxOrm.h>

#include "export.h"

#endif // _PCBAOI_PRECOMPILED_HEADER_H_

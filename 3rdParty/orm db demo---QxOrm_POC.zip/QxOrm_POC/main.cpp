#include <QGuiApplication>
#include <QQmlApplicationEngine>

#include <QxOrm_Impl.h>

#include "3rdparty/QxOrm_POC/DBEntities/pcbaoi_all_include.gen.h"
#include "common/functions.h"

void InitDB() {

  qx::QxSqlDatabase::getSingleton()->setDriverName("QMYSQL");
  qx::QxSqlDatabase::getSingleton()->setDatabaseName("3dpcbaoi");
  qx::QxSqlDatabase::getSingleton()->setHostName("localhost");
  qx::QxSqlDatabase::getSingleton()->setUserName("root");
  qx::QxSqlDatabase::getSingleton()->setPassword("123456");
  qx::QxSqlDatabase::getSingleton()->setPort(3307);
}

void DBInsert() {
  pcba_algorithm_ptr m_pcb_alg_ptr;
  m_pcb_alg_ptr.reset(new pcba_algorithm());
  m_pcb_alg_ptr->setalgorithmId(Functions::getUUidStr());
  m_pcb_alg_ptr->setnameCN("Test");
  m_pcb_alg_ptr->setnType(1);

  QSqlError daoError;
  daoError = qx::dao::insert(m_pcb_alg_ptr);

  pcba_algorithmconfig_ptr m_pcb_algconf_ptr;
  m_pcb_algconf_ptr.reset(new pcba_algorithmconfig());
  m_pcb_algconf_ptr->setalgorithmConfigId(Functions::getUUidStr());
  m_pcb_algconf_ptr->setalgorithmId(m_pcb_alg_ptr);
  m_pcb_algconf_ptr->setserial(1);
  m_pcb_algconf_ptr->setdataType(10);
  m_pcb_algconf_ptr->setdataArraySize(10);
  daoError = qx::dao::insert(m_pcb_algconf_ptr);
}

void DBUpdate() {
  QSqlError daoError;
  list_of_pcba_algorithm m_list_pcba_alg;
  daoError = qx::dao::fetch_all(m_list_pcba_alg);
  if (m_list_pcba_alg.size() > 0) {
    m_list_pcba_alg.getByIndex(0)->setnameCN("翘起"); //修改实体对象中的值
    daoError = qx::dao::update(m_list_pcba_alg); //将实体对象更新到数据库中
  }
}
void DBDel() {
  QSqlError daoError;
  list_of_pcba_algorithm m_list_pcba_alg;
  daoError = qx::dao::fetch_all(m_list_pcba_alg);
  if (m_list_pcba_alg.size() > 0) {
    daoError = qx::dao::delete_by_id(m_list_pcba_alg.getFirst());
  }
}
void DBQuery() {

  list_of_pcba_algorithm m_list_pcba_alg;
  qx::dao::fetch_all(m_list_pcba_alg);
  for (int i = 0; i < m_list_pcba_alg.count(); i++) {
    pcba_algorithm_ptr tmp = m_list_pcba_alg.getByIndex(i);
    qDebug() << tmp->getalgorithmId();
  }
}

int main(int argc, char *argv[]) {
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
  QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
  QGuiApplication app(argc, argv);

  // 数据库初始化，已经对应表的增删查改
  InitDB();
  DBInsert();
  DBQuery();
  DBUpdate();
  //  DBDel();

  QQmlApplicationEngine engine;
  const QUrl url(QStringLiteral("qrc:/main.qml"));
  QObject::connect(
      &engine, &QQmlApplicationEngine::objectCreated, &app,
      [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
          QCoreApplication::exit(-1);
      },
      Qt::QueuedConnection);
  engine.load(url);

  return app.exec();
}
